========================================================================
               CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                           [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIA E OBSERVAÇÕES ANTES DO USO
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se quiser
  alcançar 100% de exploração do mapa da Montanha Sagrada Antiga.

  ► Teclas Recomendadas:
    • Você pode usar as mesmas teclas que eu:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, também atribua teclas para Invincible e Visual.

  ► Pré-requisitos:
    • Você deve concluir todas as Missões do Arconte.
    • Se quiser executar o arquivo de Baús da forma mais tranquila possível,
      execute primeiro o arquivo de Missões.

  ► Observações de Uso:
    • Ao usar meu arquivo de Missões para concluir missões, mantenha a calma
      e vá com calma. Verifique o que a missão pede em seguida antes de
      pressionar Teleport para evitar ter que voltar ou refazer a missão.
    • Muitos quebra-cabeças na Montanha Sagrada Antiga são difíceis de
      explicar de forma intuitiva porque combinam várias ações. Se não
      entender uma etapa do quebra-cabeça, visite o Genshin Impact
      Interactive Map para assistir a guias em vídeo. A maior parte da
      dificuldade dos quebra-cabeças desta região vem da necessidade de
      usar Saurianos com muita frequência.
    • Este arquivo (e quase todos os meus arquivos) não foi feito para
      orientar jogadores que visitam a Montanha Sagrada Antiga pela primeira
      vez. Por isso, as etapas dos quebra-cabeças são bem resumidas, para
      ajudar você a evitar precisar memorizar muito e a ler diretamente os
      nomes dos waypoints para resolver os quebra-cabeças com mais facilidade.
    • Se você só pretende executar este arquivo uma vez para procurar baús,
      leia com atenção estas observações e também as notas que digitei
      cuidadosamente, uma por uma, dentro do arquivo.
    • Não recomendo usar este arquivo para serviços de boosting de contas,
      pois ele exige bastante tempo. Mas, se ainda quiser usar dessa forma,
      execute o arquivo inteiro uma vez em uma conta para entender como
      ele funciona.

========================================================================
