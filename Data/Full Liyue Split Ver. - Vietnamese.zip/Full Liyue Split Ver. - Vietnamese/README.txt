========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Liyue.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần (thực ra tính tới thời điểm tôi làm xong
      file này tôi cũng chưa làm hết Quest Ma Thần đâu).
    • Nên làm hết Quest Thế Giới có trong file, đừng skip vì có một số
      quest chứa rương, kể cả quest mở map cũng có chứa 1 số rương và nó
      có tính trong thành tựu.

  ► Lưu ý sử dụng:
    • Thực tế Liyue có 1135 rương nhưng trong file chỉ có 1129 rương vì:
      1 rương các bạn đã nhặt ở file Mondstadt đã tính vào cả Mond và
      Li, 2 rương các bạn nhặt ở Long Tích Tuyết Sơn cũng tính cho cả 2
      vùng, và 3 rương ở Natlan các bạn nhặt vì 1 lí do nào đó cũng sẽ
      tính vào Liyue (nếu bạn có thắc mắc).
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

========================================================================
