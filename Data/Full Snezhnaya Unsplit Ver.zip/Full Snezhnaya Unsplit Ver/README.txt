========================================================================
                CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, please read the following carefully if you want
  to reach 100% completion on the Snezhnaya map.

  ► Recommended key bindings:
    • You can refer to my key bindings:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      It is also recommended to assign keys for Invincible and Visual.

  ► Requirements before running:
    • Complete the Archon Quest.
    • Complete all World Quests included in the file. Do not skip them,
      because some quests contain chests. Even quests that unlock the map
      contain chests that count toward the achievement.

  ► Usage notes:
    • When using the Quest file, stay calm and read the previous note
      carefully whenever you encounter a problem. If you have tried many
      methods and still cannot proceed, ask in the Error or Chat channel.
    • If you only want to run the file once to look for chests, read these
      notes carefully as well as the notes I typed individually in the file.
    • I do not really recommend using this file for paid boosting because
      it takes time. If you still want to use it, run the entire file once
      on an account first to understand how it works.

========================================================================
