========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Liyue map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests (actually up to the point I
      finished making this file I haven't completed all Archon Quests
      either).
    • Should complete all World Quests included in the file; don't skip
      because some quests contain chests, and even map-unlocking quests
      contain some chests that count toward achievements.

  ► Usage Notes:
    • In reality, Liyue has 1,135 chests in total, but the file only
      includes 1,129 chests because: 1 chest you already collected in
      the Mondstadt file counts toward both Mondstadt and Liyue, 2
      chests collected in Dragonspine also count for both regions, and 3
      chests in Natlan that you collect will, for some reason, also
      count toward Liyue (in case you were wondering).
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

========================================================================
