========================================================================
              CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  GUIA & OBSERVAÇÕES ANTES DE USAR
------------------------------------------------------------------------
  Antes de usar este arquivo, todos precisam ler atentamente as partes
  abaixo que eu menciono se quiserem coletar 100% Oculus.

  ► Sugestão de teclas:
    • Você pode seguir como eu vinculo as teclas da seguinte forma:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, convém vincular teclas para Invincible, Visual.

  ► Requisitos antes de executar:
    • Você deve concluir o Arquivo de Quest e o Arquivo de Baús antes
      de executar este arquivo.
    • Os Hydroculus restantes estão no Mar Antigo.
========================================================================
