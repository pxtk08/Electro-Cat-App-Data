========================================================================
               CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                           [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to reach 100% exploration of the Nod-Krai map.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • You should complete all Archon Quests.
    • Please run the Quest file first if you want to run the Chest file
      as smoothly as possible.

  ► Usage Notes:
    • When using my Quest file to complete quests, stay very calm and
      patient. Check what the quest asks you to do next before pressing
      Teleport to avoid having to teleport back or redo the quest.
    • Almost all waypoints are placed so that you only need to rotate
      your camera to find what you need to interact with, so while using
      the file, try to look around.
    • If you only plan to run this file once to look for chests, please
      read the notes here as well as the notes I carefully typed out
      individually in the file.
    • I do not recommend using this file for account-boosting services
      because it takes a lot of time. However, if you still want to use
      it that way, please run through the entire file once on an account
      to understand how it works.

========================================================================
