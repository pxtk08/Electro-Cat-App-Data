========================================================================
              CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn mở hết các Điểm Dịch Chuyển.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Lưu ý sử dụng:
    • Các Điểm Dịch Chuyển trong file chủ yếu giúp bạn mở những điểm có thể
      mở ngay khi chưa làm bất kỳ nhiệm vụ nào, nên danh sách có thể chưa đủ.
    • Các Điểm Dịch Chuyển còn thiếu sẽ được hướng dẫn trong File Rương.

========================================================================
