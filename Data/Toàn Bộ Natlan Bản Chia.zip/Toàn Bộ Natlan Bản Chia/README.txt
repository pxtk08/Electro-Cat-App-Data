========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Natlan.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần.
    • Hãy chạy file Quest trước nếu muốn chạy file Rương một cách mượt
      mà nhất nhé.

  ► Lưu ý sử dụng:
    • Khi dùng file Quest của tôi để chạy quest, các bạn cần hết sức
      bình tĩnh và chậm rãi; các bạn cần xem quest yêu cầu gì tiếp theo
      rồi mới bấm tele tiếp để tránh việc phải tele lại hoặc làm lại
      quest mất thời gian.
    • Tổng rương Natlan 1 trong thành tựu là 411 rương nhưng trong file
      tôi chỉ có 408 rương vì 3 rương còn lại khá khó để lấy được. Cụ
      thể: mỗi bộ tộc trên Natlan có 2 Trụ Thử Thách Vật Tổ (tổng là 12)
      và mỗi trụ có 1 con Boss với mech đặc biệt. Mỗi Boss đều có 3
      thành tựu gắn liền với nó; các bạn cần đạt đủ 36 thành tựu tổng.
      Sau khi đạt được, các bạn sẽ nhận được 3 chiếc rương cuối cùng
      nâng tổng rương lên 411 nhé.
    • Có khá nhiều giải đố ở Natlan rất khó để tôi hướng dẫn một cách
      trực quan vì nó lồng rất nhiều hành động vào nhau; nếu không hiểu
      bước giải đố nào, hãy lên Genshin Impact Interactive Map để xem
      hướng dẫn bằng video nhé. Phần lớn độ khó của giải đố vùng này đến
      từ việc phải sử dụng quá thường xuyên Saurian.
    • Các Khiêu Chiến Saurian ở chỗ NPC thường cho 3 rương với điều kiện
      đạt mức SS, vì vậy các bạn chú ý đạt đủ mốc điểm ngay từ lần đầu
      để tránh mất thời gian.
    • File này (và hầu như các file của tôi) không thiết kế để hướng dẫn
      người mới chơi lần đầu Natlan nên tôi thường viết khá ngắn gọn các
      bước giải đố, mục đích chỉ giúp các bạn không cần nhớ nhiều mà có
      thể đọc ngay trên tên waypoint để dễ dàng giải đố hơn thôi.
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

========================================================================
