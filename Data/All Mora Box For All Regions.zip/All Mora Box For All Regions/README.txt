Custom TP File By pxtk.08 - Vietnamese & English - Free



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Nhặt Full Các Rương Mora Nhé.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần Vì Có Khá Nhiều Rương Mora Có Thể Nhặt Trong Nhiệm Vụ Ma Thần (Đặc Biệt Là Nod-Krai)

- Trước Khi Chạy File Này Thì Các Bạn Nên Chạy Hết File Chest Và Quest Của Tất Cả Các Vùng Trước.

- Phần Giải Đố Trong File Đa Số Tôi Ghi Là "Puzzle" Vì Nó Khá Đơn Giản. Nếu Các Bạn Vướng Chỗ Nào Có Thể Tìm Kiếm Vị Trí Đó Trên Genshin Impact Interactive Map Để Xem Comment Hướng Dẫn Trên Đó.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Mondstadt Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- You should complete all the Archon Quests, because there are quite a lot of Mora Chests you can collect during them (especially in Nod-Krai).

- Before running this file, please run the Chest and Quest files for all regions first.

- Most of the puzzles in this file are just labeled "Puzzle" because they're fairly simple. If you get stuck on one, you can look up that location on the Genshin Impact Interactive Map and check the comments there for a guide.
