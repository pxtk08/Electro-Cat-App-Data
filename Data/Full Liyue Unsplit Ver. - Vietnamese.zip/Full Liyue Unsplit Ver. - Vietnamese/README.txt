Custom TP File By pxtk.08 - Vietnamese & English - Free



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Liyue.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần (Thực Ra Tính Tới Thời Điểm Tôi Làm Xong File Này Tôi Cũng Chưa Làm Hết Quest Ma Thần Đâu).

- Nên Làm Hết Quest Thế Giới Có Trong File, Đừng Skip Vì Có Một Số Quest Chứa Rương, Kể Cả Quest Mở Map Cũng Có Chứa 1 Số Rương Và Nó Có Tính Trong Thành Tựu.

- Thực Tế Liyue Có 1135 Rương Nhưng Trong File Chỉ Có 1129 Rương Vì: 1 Rương Các Bạn Đã Nhặt Ở File Mondstadt Đã Tính Vào Cả Mond Và Li, 2 Rương Các Bạn Nhặt Ở Long Tích Tuyết Sơn Cũng Tính Cho Cả 2 Vùng, 3 Rương Ở Natlan Các Bạn Nhặt Vì 1 Lí Do Nào Đó Cũng Sẽ Tính Vào Liyue. Nếu Bạn Có Thắc Mắc.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Liyue Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All Archon Quests (Actually Up To The Point I Finished Making This File I Haven't Completed All Archon Quests Either).

- Should Complete All World Quests Included In The File, Don't Skip Because Some Quests Contain Chests, Even Map Unlocking Quests Contain Some Chests And They Count In Achievements.

- In reality, Liyue has 1,135 chests in total, but the file only includes 1,129 chests because: 1 chest you already collected in the Mondstadt file counts towards both Mondstadt and Liyue, 2 chests collected in Dragonspine also count for both regions, and 3 chests in Natlan that you collect will, for some reason, also count toward Liyue. If you have any questions.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.


