========================================================================
             CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser coletar todos os Baús de Mora.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte, pois muitos
      Baús de Mora podem ser coletados durante elas (especialmente em Nod-Krai).
    • Você deve concluir primeiro os arquivos de Baús e Missões de todas as regiões.

  ► Notas de Uso:
    • A maioria dos quebra-cabeças neste arquivo está marcada como "Puzzle"
      porque são relativamente simples. Se ficar preso, procure a localização
      no Genshin Impact Interactive Map e confira os comentários de guia.

========================================================================
