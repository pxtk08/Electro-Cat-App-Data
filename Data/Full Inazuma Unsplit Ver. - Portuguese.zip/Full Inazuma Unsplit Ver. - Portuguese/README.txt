========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser alcançar 100% de exploração no mapa de Inazuma.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte (na verdade,
      até o momento em que terminei este arquivo, nem eu mesmo tinha
      concluído todas).
    • É recomendável concluir todas as Missões do Mundo incluídas no
      arquivo; não pule nenhuma, pois algumas contêm baús - até mesmo
      missões de desbloqueio de mapa contêm baús que contam para
      conquistas.
    • Existem 2 ou 3 missões em que é preciso enfrentar alvos nos quais
      o Kill Aura não funciona; certifique-se de fortalecer e subir o
      nível dos seus personagens, ou então diminua o Nível do Mundo para
      fazê-las.

  ► Notas de Uso:
    • Há muitas missões neste arquivo que reiniciam com base no tempo
      real; em média, se você rodar o arquivo completo no primeiro dia
      (em contas novas), levará de 8 a 9 dias para concluir todas elas.
      Se dividir em 2 dias diferentes, pode chegar a 9-10 dias ou mais.
      Recomendo reservar um dia livre antes de usar este arquivo. É
      difícil explicar em palavras - basta começar a usar que você vai
      entender...
    • Ao brincar com o Garoto Kujirai, espere a contagem regressiva
      terminar antes de se teleportar para o próximo ponto. Caso
      contrário, pode bugar e você ficará preso para sempre mesmo
      relogando, além de não receber o baú. Eu já buguei uma conta com 7
      dias de farm e mais de 250 tiros e acabei deletando a conta por
      TOC desse baú.
    • As Seelies de Inazuma se movem bem rápido; você pode aumentar o
      FOV para acompanhar melhor o caminho delas.
    • Se você só precisa rodar o arquivo uma única vez para procurar
      baús, leia com atenção os avisos aqui, bem como as notas que eu
      digitei cuidadosamente uma por uma dentro do arquivo.
    • Quanto a quem pretende usar este arquivo para serviços de boost /
      pilot de contas, eu não recomendo muito porque leva um pouco de
      tempo. Mas, se mesmo assim quiser usar, faça uma passagem completa
      pelo arquivo em alguma conta primeiro para ter uma noção geral de
      como ele funciona.

------------------------------------------------------------------------
  NOTAS PARA A ILHA NARUKAMI
------------------------------------------------------------------------
    • Para as missões desta ilha, se ocorrer algum bug ou travamento
      seguindo o arquivo, envie uma mensagem com captura de tela + o
      nome da missão específica.
    • Baú do Tanuki: este baú não pode ser pego normalmente; ao chegar
      nele, leia com atenção a nota que deixei dentro do arquivo.
    • Se ao se teleportar para algumas ilhotas a noroeste da Ilha
      Narukami um guarda barrar você pedindo para entregar uma carta,
      faça essa missão na hora. Fiquei com preguiça de incluí-la porque
      nos testes em outras contas ela não afetou o arquivo.
    • Há 1 Baú Precioso mencionado no arquivo que pode ser pego entrando
      via glitch. Mas, se ainda quiser fazer a missão correspondente, o
      nome dela é "The Very Special Fortune Slip" (Um Bilhete da Sorte
      Muito Especial). Durante o arquivo você verá um waypoint indicando
      o ponto inicial; veja os detalhes no YouTube.

------------------------------------------------------------------------
  NOTAS PARA A ILHA KANNAZUKA
------------------------------------------------------------------------
    • Os guias de operação dos canhões podem ficar ligeiramente
      desalinhados se você deixar para o próximo dia de reset. Por isso,
      recomenda-se rodar o arquivo em uma única sessão.

------------------------------------------------------------------------
  NOTAS PARA A ILHA TSURUMI
------------------------------------------------------------------------
    • Se estiver usando o arquivo para procurar baús e precisar saber em
      qual dia está, teleporte-se para o ponto próximo ao Local
      Cerimonial e olhe ao redor. Se vir 1 Feiticeiro do Abismo com 1
      tocha, é o Dia 1; com 2 tochas, Dia 2; com 3 tochas, Dia 3.

========================================================================
