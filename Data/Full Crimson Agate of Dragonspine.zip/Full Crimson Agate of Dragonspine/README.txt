========================================================================
              CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, everyone needs to read carefully the parts I
  mention below if you want to collect 100% Crimson Agate.

  ► Suggested Keybinds:
    • You can refer to how I bind the keys as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keys for Invincible, Visual.

  ► Requirements Before Running:
    • You should finish the Quest File and Chest File first before
      running this file.
    • This file omits all Crimson Agate already collected in the Quest File
      and the Chest File, so you must finish the Chest and Quest files first
      before running this file if you want all Oculi.

========================================================================
