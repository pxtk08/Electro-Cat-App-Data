========================================================================
              CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn nhặt 100% Thần Đồng.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Các bạn nên chạy xong File Quest và File Rương trước rồi mới chạy
      đến File này.
========================================================================
