========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Natlan map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests.
    • Please run the Quest file first if you want to run the Chest file
      as smoothly as possible.

  ► Usage Notes:
    • When using my Quest file to run quests, please take it slow and
      stay patient. Check what the quest requires next before
      teleporting to the next spot to avoid having to re-teleport or
      redo the quest, which wastes time.
    • The Natlan 1 chest total in the achievements is 411 chests, but my
      file only has 408 because the remaining 3 chests are quite hard to
      obtain. Details: each tribe in Natlan has 2 Totem Challenge
      Pillars (12 in total), and each pillar has 1 boss with special
      mechanics. Every boss has 3 achievements tied to it, and you need
      to earn all 36 achievements in total to receive the final 3
      chests, bringing the total up to 411.
    • There are quite a lot of puzzles in Natlan, and it's hard to guide
      through them visually because they chain many actions together. If
      you don't understand a puzzle step, check the Genshin Impact
      Interactive Map for a video guide. Most of the difficulty here
      comes from having to use Saurians very frequently.
    • The Saurian Challenges at NPCs usually give 3 chests if you reach
      SS Rank, so make sure you hit the required score on the first try
      to avoid wasting time.
    • This file (and most of my files) is not designed to guide
      first-time players through Natlan, so I usually write
      puzzle-solving steps quite briefly - simply to spare you from
      having to remember a lot so you can read the waypoint name
      directly and solve the puzzle more easily.
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

========================================================================
