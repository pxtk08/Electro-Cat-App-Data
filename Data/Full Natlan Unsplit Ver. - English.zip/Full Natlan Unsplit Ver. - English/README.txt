Custom TP File By pxtk.08 - Vietnamese & English - Free



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Natlan.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần.

- Khi Dùng File Quest Của Tôi Để Chạy Quest, Các Bạn Cần Hết Sức Bình Tĩnh Và Chậm Rãi, Các Bạn Cần Xem Quest Yêu Cầu Gì Tiếp Theo Rồi Mới Bấm Tele Tiếp Để Tránh Việc Phải Tele Lại Hoặc Làm Lại Quest Mất Thời Gian

- Hãy Chạy File Quest Trước Nếu Muốn Chạy File Rương Một Cách Mượt Mà Nhất Nhé.

- Có Khá Nhiều Giải Đố Ở Natlan Rất Khó Để Tôi Có Thể Hướng Dẫn Một Cách Trực Quan Vì Nó Lồng Rất Nhiều Hành Động Vào Với Nhau, Vì Vậy Nếu Các Bạn Không Hiểu Bước Giải Đố Nào, Hãy Lên Genshin Impact Interactive Map Để Kiếm Xem Hướng Dẫn Bằng Video Nhé. Phần Lớn Độ Khó Của Giải Đố Vùng Này Là Đến Từ Việc Phải Sử Dụng Quá Thường Xuyên Saurian.

- Các Khiêu Chiến Saurian Ở Chỗ NPC Thường Cho 3 Rương Với Điều Kiện Đạt Mức SS, Vì Vậy Các Bạn Chú Ý Đạt Đủ Mốc Điểm Ngay Từ Lần Đầu Để Tránh Mất Thời Gian.

- File Này Và Hầu Như Các File Của Tôi Không Thiết Kế Để Hướng Dẫn Người Mới Chơi Lần Đầu Natlan Vì Vậy Tôi Thường Viết Khá Ngắn Gọn Các Bước Giải Đố. Mục Đích Chỉ Giúp Các Bạn Không Cần Phải Nhớ Nhiều Mà Có Thể Đọc Ngay Trên Tên Waypoint Để Dễ Dàng Giải Đố Hơn Thôi.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Natlan Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All Archon Quests.

- When Using My Quest File To Run Quests, Please Take It Slow And Stay Patient. You Need To Check What The Quest Requires Next Before Teleporting To The Next Spot To Avoid Having To Re-teleport Or Redo The Quest, Which Wastes Time.

- Please Run The Quest File First If You Want To Run The Chest File As Smoothly As Possible

- There are quite a lot of puzzles in Natlan, and it's hard for me to guide you through them visually because they chain many actions together. So if you don't understand a puzzle step, head over to the Genshin Impact Interactive Map to look up a video guide. Most of the difficulty of this region's puzzles comes from having to use Saurians far too often.

- The Saurian Challenges at the NPC usually give 3 chests if you reach SS rank, so make sure you hit the required score on the first try to avoid wasting time.

- This file, and most of my files, are not designed to guide first-time players through Natlan, so I usually write the puzzle-solving steps quite briefly. The goal is simply to spare you from having to remember a lot, so you can read the waypoint name directly and solve the puzzle more easily.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.
