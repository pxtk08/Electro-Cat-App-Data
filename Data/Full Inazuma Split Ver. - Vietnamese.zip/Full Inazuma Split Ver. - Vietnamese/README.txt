========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Inazuma.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần (thực ra tính tới thời điểm tôi làm xong
      file này tôi cũng chưa làm hết Quest Ma Thần đâu).
    • Nên làm hết Quest Thế Giới có trong file, đừng skip vì có một số
      quest chứa rương, kể cả quest mở map cũng có chứa 1 số rương và nó
      có tính trong thành tựu.
    • Có 2-3 quest cần đánh một số thứ mà Kill Aura không có hiệu quả
      với chúng; hãy đảm bảo build nhân vật và nâng cấp nhân vật lên
      nhé, hoặc có 1 lựa chọn khác là ép Cấp Thế Giới để làm.

  ► Lưu ý sử dụng:
    • Các quest reset theo thời gian ngoài đời trong file này rất nhiều;
      trung bình nếu các bạn chạy full hết file trong ngày đầu (đối với
      acc mới) thì sẽ tốn từ 8-9 ngày để làm xong toàn bộ quest đó. Nếu
      các bạn chạy file này trong 2 ngày khác nhau thì có thể cộng thêm
      thành 9-10 ngày hoặc hơn thế. Tôi khuyên nếu có thể hãy dành ra
      một ngày rảnh hẵng dùng file này. Cũng khá khó để giải thích nên
      cứ bắt tay vào chạy thử là hiểu...
    • Khi các bạn chơi với cậu bé Kujirai, hãy đợi hết thời gian đếm rồi
      mới tele tiếp. Nếu không thì có thể lỗi và bạn sẽ kẹt mãi kể cả có
      out ra vào lại game, đồng thời cũng không nhận được rương đâu. Tôi
      đã từng lỗi 1 acc cày trong 7 ngày hơn 250 roll và vì OCD cái
      rương này nên xóa hẳn tài khoản đi rồi.
    • Các Tiên Linh ở Inazuma di chuyển khá nhanh, các bạn có thể kéo
      FOV tăng lên để có thể dễ bao quát hơn đường đi của chúng nhé.
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

------------------------------------------------------------------------
  LƯU Ý RIÊNG CHO ĐẢO NARUKAMI
------------------------------------------------------------------------
    • Đối với các quest trên đảo này, nếu có bất cứ bug hay bị kẹt ở đâu
      trong khi chạy theo file của tôi thì hãy gửi tin nhắn và ảnh màn
      hình + quest cụ thể.
    • Rương Tanuki: rương này không thể nhặt như bình thường; khi các
      bạn chạy tới rương đó, hãy đọc kĩ note mà tôi ghi ở trong.
    • Nếu trong lúc tele ra một số đảo nhỏ ở phía Tây Bắc đảo Narukami
      mà bị 1 anh lính chặn lại và yêu cầu giao thư thì hãy làm luôn
      quest đó nhé. Tôi lười gắn vào trong file vì chạy thử file ở acc
      khác thì không thấy bị ảnh hưởng.
    • Có 1 rương hiếm như trong file tôi đã nói thì có thể dùng bug để
      chui vào lấy. Nhưng trong trường hợp các bạn vẫn muốn làm quest đó
      thì nó tên là "The Very Special Fortune Slip". Trong lúc chạy file
      các bạn sẽ thấy có một waypoint tên là "Có thể đọc hoặc skip" thì
      đó chính là nơi bắt đầu của quest; chi tiết lên YouTube xem nhé.

------------------------------------------------------------------------
  LƯU Ý RIÊNG CHO ĐẢO KANNAZUKA
------------------------------------------------------------------------
    • Các hướng dẫn cách vận hành pháo để bắn đôi khi sẽ hoạt động hơi
      sai lệch chút nếu các bạn để sang ngày reset tiếp theo. Vì vậy các
      bạn nên chạy qua một lượt file như tôi đã nói trong mục Nhắc nhở
      chung.

------------------------------------------------------------------------
  LƯU Ý RIÊNG CHO ĐẢO TSURUMI
------------------------------------------------------------------------
    • Nếu các bạn là người cần dùng file với mục đích dò rương thì để
      xác định số ngày mà bạn đang ở, hãy tele đến điểm tele gần Tế Đàn
      và nhìn xung quanh. Nếu bạn nhìn thấy có Pháp Sư Vực Sâu đứng cùng
      1 cây đuốc, đó là Ngày 1. Tương tự, Ngày 2 là 2 cây đuốc và Ngày 3
      là 3 cây đuốc. Cứ quan sát xung quanh là sẽ thấy.

========================================================================
