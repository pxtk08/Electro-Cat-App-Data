========================================================================
              CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn nhặt full các Rương Mora.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần, vì có khá nhiều Rương Mora có thể
      nhặt trong nhiệm vụ Ma Thần (đặc biệt là Nod-Krai).
    • Nên chạy xong File Chest và File Quest của tất cả các vùng trước.

  ► Lưu ý sử dụng:
    • Phần giải đố trong file đa số được ghi là "Puzzle" vì khá đơn giản.
      Nếu bị kẹt, bạn có thể tìm vị trí đó trên Genshin Impact Interactive
      Map để xem comment hướng dẫn.

========================================================================
