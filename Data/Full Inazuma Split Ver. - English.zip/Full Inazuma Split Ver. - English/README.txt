========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Inazuma map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests (actually up to the point I
      finished making this file I haven't completed all Archon Quests
      either).
    • Should complete all World Quests included in the file; don't skip
      because some quests contain chests, and even map-unlocking quests
      contain some chests that count toward achievements.
    • There are 2-3 quests where you need to fight things that Kill Aura
      is not effective against; please make sure to build and level up
      your characters, or another option is lowering your World Level to
      do them.

  ► Usage Notes:
    • There are many quests in this file that reset based on real-life
      time; on average if you run the full file on day 1 (for new
      accounts) it will take 8-9 days to finish all of those quests. If
      you run this file across 2 different days it can add up to 9-10
      days or more. I advise spending a free day if possible before
      using this file. It is quite hard to explain, so just start
      running it and you will understand...
    • When playing with Kid Kujirai, please wait until the countdown
      timer ends before teleporting next. Otherwise it might glitch and
      you will be stuck forever even if you relog, and you will not
      receive the chest either. I once glitched an account farmed for
      over 7 days with more than 250 pulls, and because of OCD about
      this chest I completely deleted the account.
    • Inazuma Seelies move quite fast; you can increase your FOV to
      easily get a better view of their movement paths.
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

------------------------------------------------------------------------
  NARUKAMI ISLAND NOTES
------------------------------------------------------------------------
    • For quests on this island, if there is any bug or you get stuck
      anywhere while following my file, send a message with a screenshot
      + the specific quest.
    • Tanuki Chest: this chest cannot be collected normally; when you
      reach that chest, read the in-file note carefully.
    • If while teleporting to some small islands northwest of Narukami
      Island you get blocked by a guard asking you to deliver a letter,
      do that quest right away. I was too lazy to include it in the file
      because testing on other accounts showed no issue.
    • There is 1 Precious Chest as mentioned in the file that you can
      glitch-clip inside to collect. But if you still want to do that
      quest, its name is "The Very Special Fortune Slip". While running
      the file you will see a waypoint named "Read This Or Skip", which
      is the exact starting point of the quest; search YouTube for
      details.

------------------------------------------------------------------------
  KANNAZUKA ISLAND NOTES
------------------------------------------------------------------------
    • Guides on operating cannons to shoot may sometimes work slightly
      off if you leave them until the next reset day. Therefore, you
      should run through the file in one session as mentioned above.

------------------------------------------------------------------------
  TSURUMI ISLAND NOTES
------------------------------------------------------------------------
    • If you are using this file for chest scanning and need to tell
      which day you are currently on, teleport to the waypoint near the
      Ceremonial Site and look around. If you see 1 Abyss Mage standing
      with 1 torch, that is Day 1. Similarly, Day 2 has 2 torches and
      Day 3 has 3 torches. Just look around and you will see.

========================================================================
