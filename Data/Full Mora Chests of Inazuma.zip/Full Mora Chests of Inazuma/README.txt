========================================================================
               CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to collect all Mora Chests.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • You should complete all Archon Quests, as many Mora Chests can be
      collected during Archon Quests (especially in Nod-Krai).
    • You should finish the Chest and Quest files for all regions first.

  ► Usage Notes:
    • Most puzzles in this file are labeled "Puzzle" because they are
      fairly simple. If you get stuck, search for the location on the
      Genshin Impact Interactive Map and check the guide comments.

========================================================================
