========================================================================
              CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, everyone needs to read carefully the parts I
  mention below if you want to collect 100% Shadow Wingdrop.

  ► Suggested Keybinds:
    • You can refer to how I bind the keys as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keys for Invincible, Visual.

  ► Requirements Before Running:
    • You should finish the Quest File and Chest File first before
      running this file.
    • Since Shadow Wingdrop is a rather special item, I have included
      the guide in this file as well.
========================================================================
