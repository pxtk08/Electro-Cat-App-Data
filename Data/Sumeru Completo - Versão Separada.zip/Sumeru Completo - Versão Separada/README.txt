========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser alcançar 100% de exploração no mapa de Sumeru.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte.
    • Execute o arquivo de Missões primeiro se quiser rodar o arquivo de
      Baús da forma mais tranquila possível.
    • É necessário concluir a missão de desbloqueio do Despenhadeiro
      para obter a Pintura #10 (já incluída no arquivo de Missões).
    • Prepare a Isca de Orvalho (isca de pesca de Sumeru) com
      antecedência.

  ► Notas de Uso:
    • Ao usar meu arquivo de Missões, vá com calma e paciência: confira
      o que a missão pede em seguida antes de se teleportar para o
      próximo ponto, evitando ter que refazer o teleporte ou a missão.
    • As instruções dentro dos Domínios das missões incluídas no arquivo
      são obrigatórias e não podem ser puladas.
    • Se você não receber a missão "Vistas Estáticas: Parte 2" após
      tentar tudo no guia, teleporte-se para o local da Pintura #8 que
      anotei, relogue o jogo lá e a missão aparecerá (lembre-se de pegar
      o baú antes de relogar).
    • Fique atento aos Constructos Primordiais com barra de vida de
      chefe: há 5 deles e você precisa derrotar todos para obter os 5
      componentes necessários para desbloquear os Obeliscos Primordiais
      depois.
    • Em Sumeru há vários baús que só aparecem após derrotar todos os
      inimigos ao redor, então preste atenção para coletar todos.
    • Há 1 baú que exige a conclusão da Missão do Arconte para ser
      obtido.
    • Se você só precisa rodar o arquivo uma única vez para procurar
      baús, leia com atenção os avisos aqui, bem como as notas que eu
      digitei cuidadosamente uma por uma dentro do arquivo.
    • Quanto a quem pretende usar este arquivo para serviços de boost /
      pilot de contas, eu não recomendo muito porque leva um pouco de
      tempo. Mas, se mesmo assim quiser usar, faça uma passagem completa
      pelo arquivo em alguma conta primeiro para ter uma noção geral de
      como ele funciona.

========================================================================
