========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser alcançar 100% de exploração no mapa de Fontaine.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte.
    • Execute o arquivo de Missões primeiro se quiser rodar o arquivo de
      Baús da forma mais tranquila possível.

  ► Notas de Uso:
    • Ao usar meu arquivo de Missões, vá com calma e paciência: confira
      o que a missão pede em seguida antes de se teleportar para o
      próximo ponto, evitando ter que refazer o teleporte ou a missão.
    • Alguns pontos no arquivo de Baús exigem desligar o Kill Aura, caso
      contrário você pode assustar e afastar as pequenas focas por
      acidente. Fique atento a isso.
    • Nos quebra-cabeças de bolhas de água, preste atenção à ordem de
      ativação e ao intervalo de tempo ao estourar cada bolha.
    • A maioria dos quebra-cabeças já possui instruções, e os poucos sem
      guia detalhado são bem simples. Alguns (como os subaquáticos)
      podem ser difíceis de visualizar apenas pelo arquivo - recomendo
      combinar com vídeos no YouTube ou o Interactive Map.
    • Preste atenção nos robôs com barra de vida de chefe; você precisa
      coletar todos os 7 componentes para abrir o baú depois.
    • Em Fontaine, alguns baús só aparecem após derrotar os inimigos ao
      redor, então preste atenção para coletar todos.
    • Se você só precisa rodar o arquivo uma única vez para procurar
      baús, leia com atenção os avisos aqui, bem como as notas que eu
      digitei cuidadosamente uma por uma dentro do arquivo.
    • Quanto a quem pretende usar este arquivo para serviços de boost /
      pilot de contas, eu não recomendo muito porque leva um pouco de
      tempo. Mas, se mesmo assim quiser usar, faça uma passagem completa
      pelo arquivo em alguma conta primeiro para ter uma noção geral de
      como ele funciona.

========================================================================
