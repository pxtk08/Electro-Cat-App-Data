Custom TP File By pxtk.08 - Vietnamese & English & Portuguese - Free

- Special Thanks To @sukii0oo For Translating This File To Portuguese


Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Inazuma.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần (Thực Ra Tính Tới Thời Điểm Tôi Làm Xong File Này Tôi Cũng Chưa Làm Hết Quest Ma Thần Đâu).

- Nên Làm Hết Quest Thế Giới Có Trong File, Đừng Skip Vì Có Một Số Quest Chứa Rương, Kể Cả Quest Mở Map Cũng Có Chứa 1 Số Rương Và Nó Có Tính Trong Thành Tựu.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.

- Các Quest Reset Theo Thời Gian Ngoài Đời Trong File Này Rất Nhiều, Trung Bình Nếu Các Bạn Chạy Full Hết File Trong Ngày Đầu (Đối Với Acc Mới) Thì Sẽ Tốn Từ 8-9 Ngày Để Làm Xong Toàn Bộ Quest Đó, Nếu Ví Dụ Các Bạn Chạy File Này Trong 2 Ngày Khác Nhau Thì Có Thể + Thêm Thành 9-10 Hoặc Hơn Thế. Tôi Khuyên Nếu Có Thể Hãy Dành Ra Một Ngày Rảnh Hẵng Dùng File Này. Cũng Khá Khó Để Giải Thích Nên Cứ Bắt Tay Vào Chạy Thử Là Hiểu.......

- Có 2 -3 Quest Cần Đánh Một Số Thứ Mà Kill Aura Không Có Hiệu Quả Với Chúng, Hãy Đảm Bảo Build Nhân Vật Và Nâng Cấp Nhân Vật Lên Nhé, Hoặc Có 1 Lựa Chọn Khác là Ép Cấp Thế Giới Để Làm.

- Khi Các Bạn Chơi Với Cậu Bé Kujirai, Hãy Đợi Hết Thời Gian Đếm Rồi Mới Tele Tiếp. Nếu Không Thì Có Thể Lỗi Và Bạn Sẽ Kẹt Mãi Kể Cả Có Out Ra Vào Lại Game, Đồng Thời Cũng Không Nhận Được Rương Đâu. Tôi Đã Từng Lỗi 1 Acc Cày Trong 7 ngày Hơn 250 Roll Và Vì OCD Cái Rương Này Nên Xóa Hẳn Tài Khoản Đi Rồi.

- Các Tiên Linh Ở Inazuma Di Chuyển Khá Nhanh, Các Bạn Có Thể Kéo FOV Tăng Lên Để Có Thể Dễ Bao Quát Hơn Đường Đi Của Chúng Nhé.

- Hướng Dẫn Dùng Entity Teleport Sẽ Là Video Số (1) Nhé

- Xin Lỗi Vì Chất Lượng Video Quay Màn Hình Không Được Tốt Lắm Vì Nó Là Vid Cắt




Đối Với Đảo Narukami, Sẽ Có Một Số Điều Sau Đây Cần Lưu Ý:

- Đối Với Các Quest Trên Đảo Này, Nếu Có Bất Cứ Bug Hay Bị Kẹt Ở Đâu Trong Khi Chạy Theo File Của Tôi Thì Hãy Gửi Tin Nhắn Và Ảnh Màn Hình + Quest Cụ Thể.

- Rương Tanuki: Rương Này Không Thể Nhặt Như Bình Thường, Khi Các Bạn Chạy Tới Rương Đó, Hãy Đọc Kĩ Note Mà Tôi Ghi Ở Trong. Nếu Như Vẫn Không Hiểu Thì Có Thể Xem Video (2) Mà Tôi Đính Kèm Trong File.

- Nếu Trong Lúc Tele Ra Một Số Đảo Nhỏ Ở Phía Tây Bắc Đảo Narukami Mà Bị 1 Anh Lính Chặn Lại Và Yêu Cầu Giao Thư Thì Hãy Làm Luôn Quest Đó Nhé. Tôi Lười Gắn Vào Trong File Vì Chạy Thử File Ở Acc Khác Thì Không Thấy Bị Ảnh Hưởng

- Có 1 Rương Hiếm Như Trong File Tôi Đã Nói Thì Có Thể Dùng Bug Để Chui Vào Lấy. Nhưng Trong Trường Hợp Các Bạn Vẫn Muốn Làm Quest Đó thì Nó Tên Là "The Very Special Fortune Slip".Trong Lúc Chạy File Các Bạn Sẽ Thấy Có Một Waypoint tên là "Có thể đọc hoặc skip" thì đó chính là nơi bắt đầu của quest. Chi Tiết Lên Youtube Xem Nhé.




Đối Với Đảo Kannazuka, Sẽ Có Một Số Điều Sau Đây Cần Lưu Ý:

- Các Hướng Dẫn Cách Vận Hành Pháo Để Bắn Đôi Khi Sẽ Hoạt Động Hơi Sai Lệch Chút Nếu Các Bạn Để Sang Ngày Reset Tiếp Theo. Vì Vậy Các Bạn Nên Chạy Qua Một Lượt File Như Tôi Đã Nói Trong Mục Nhắc Nhở Chung




Đói Với Đảo Tsurumi, Sẽ Có Một Số Điều Sau Đây Cần Lưu Ý:

- Nếu Các Bạn Là Người Cần Dùng File Với Mục Đích Dò Rương Thì Để Xác Định Số Ngày Mà Bạn Đang Ở, Hãy Tele Đến Điểm Tele Gần Tế Đàn Và Nhìn Xung Quanh. Nếu Bạn Nhìn Thấy Có Pháp Sư Vực Sâu Đứng Cùng 1 Cây Đuốc; Đó Là Ngày 1. Tương Tự, Ngày 2 Là 2 Cây Đuốc Và Ngày 3 Là 3 Cây Đuốc. Cứ Quan Sát Xung Quanh Là Sẽ Thấy. Còn Nếu Vẫn Chưa Rõ Thì Tôi Sẽ Đính Kèm Video Trong File Này Luôn. Video Số (3) Nhé.



Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Inazuma Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All Archon Quests (Actually Up To The Point I Finished Making This File I Haven't Completed All Archon Quests Either).

- Should Complete All World Quests Included In The File, Don't Skip Because Some Quests Contain Chests, Even Map Unlocking Quests Contain Some Chests And They Count In Achievements.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.

- Quests That Reset Based On Real Life Time In This File Are Very Many, On Average If You Run Through The Full File On The First Day (For New Accs) It Will Take From 8-9 Days To Complete All Those Quests, If For Example You Run This File On 2 Different Days Then It Can Add Up To 9-10 Days Or More. I Advise If Possible Spend A Free Day Before Using This File. It Is Also Quite Difficult To Explain So Just Get Started On Running It And You Will Understand.......

- There Are 2 - 3 Quests That Need To Fight Some Things That Kill Aura Is Not Effective Against Them, Please Make Sure To Build Characters And Level Up Characters, Or There Is Another Option Which Is Lowering World Level To Do It.

- When You Play With Kid Kujirai, Please Wait Until The Countdown Timer Ends Before Teleporting Next. Otherwise It Might Glitch And You Will Be Stuck Forever Even If You Relog Game, At The Same Time You Will Not Receive The Chest Either. I Once Glitched 1 Account Grinded For Over 7 Days With More Than 250 Rolls And Because Of OCD About This Chest I Completely Deleted The Account Already.

- Inazuma Seelies Move Quite Fast, You Guys Can Increase FOV To Easily Get A Better View Of Their Movement Paths.

- Guide On How To Use Entity Teleport Will Be Video Number (1)

- Sorry For The Poor Screen Recording Video Quality Because It Is A Clipped Video


For Narukami Island, There Will Be A Few Things Below To Note:

- For Quests On This Island, If There Is Any Bug Or You Get Stuck Anywhere While Running According To My File Then Send A Message And Screenshot + Specific Quest.

- Tanuki Chest: This Chest Cannot Be Collected Like Normal, When You Run To That Chest, Read Carefully The Note That I Wrote Inside. If Still Don't Understand Then Can Watch Video (2) That I Attached In The File.

- If While Teleporting To Some Small Islands Northwest Of Narukami Island You Get Blocked By A Guard And Requested To Deliver A Letter Then Do That Quest Right Away. I Was Too Lazy To Put It In The File Because Testing The File On Other Accs I Didn't See It Getting Affected.

- There Is 1 Precious Chest As Mentioned In The File That Can Use Glitch Clipping To Get Inside And Collect. But In Case You Guys Still Want To Do That Quest Its Name Is "The Very Special Fortune Slip". While Running The File You Will See A Waypoint Named "Read This Or Skip" Then That Is Exact Starting Place Of The Quest. Search Youtube For Details.



For Kannazuka Island, There Will Be A Few Things Below To Note:

- Guides On How To Operate Cannons To Shoot Sometimes Will Work Slightly Off If You Guys Leave It To The Next Reset Day. Therefore You Should Run Through File In One Session As I Said In The General Reminders Section.



For Tsurumi Island, There Will Be A Few Things Below To Note:

-If You Are A Person Who Needs To Use The File For Chest Scanning Purposes Then To Determine The Number Of Days You Are Currently On, Teleport To The Waypoint Near The Ceremonial Site And Look Around. If You See 1 Abyss Mage Standing With 1 Torch; That Is Day 1. Similarly, Day 2 Is 2 Torches And Day 3 Is 3 Torches. Just Observe Around And You Will See. If Still Unclear Then I Will Attach Video In This File Right Away. Video Number (3).