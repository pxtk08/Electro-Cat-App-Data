========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Sumeru map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests.
    • Please run the Quest file first if you want to run the Chest file
      as smoothly as possible.
    • Need to complete The Chasm unlock quest to get Painting #10
      (already included in the Quest file).
    • Please prepare Sugardew Bait (Sumeru fishing bait) in advance.

  ► Usage Notes:
    • When using my Quest file to run quests, please take it slow and
      stay patient. Check what the quest requires next before
      teleporting to the next spot to avoid having to re-teleport or
      redo the quest, which wastes time.
    • Instructions inside Domain quests included in the file are
      mandatory and cannot be skipped (feel free to test if you want).
    • If you don't get the "Static Views: Part 2" quest after trying
      everything in the guide, teleport to Painting location #8 that I
      noted, relog the game there, and you will get the quest (remember
      to collect the chest before relogging).
    • Pay attention to Primal Constructs with boss health bars: there
      are 5 of them, and you need to defeat all 5 to get components
      needed for unlocking Primal Obelisks later.
    • Many Sumeru chests only spawn after defeating all surrounding
      enemies, so pay attention to collect them all.
    • There is 1 chest that requires completing the Archon Quest to
      obtain.
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

========================================================================
