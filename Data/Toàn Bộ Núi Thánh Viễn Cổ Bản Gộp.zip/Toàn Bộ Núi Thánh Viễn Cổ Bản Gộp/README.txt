========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Núi Thánh Viễn Cổ.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần.
    • Hãy chạy file Quest trước nếu muốn chạy file Rương một cách mượt
      mà nhất nhé.

  ► Lưu ý sử dụng:
    • Khi dùng file Quest của tôi để chạy quest, các bạn cần hết sức
      bình tĩnh và chậm rãi; các bạn cần xem quest yêu cầu gì tiếp theo
      rồi mới bấm tele tiếp để tránh việc phải tele lại hoặc làm lại
      quest mất thời gian.
    • Có khá nhiều giải đố ở Núi Thánh Viễn Cổ rất khó để tôi hướng dẫn một cách
      trực quan vì nó lồng rất nhiều hành động vào nhau; nếu không hiểu
      bước giải đố nào, hãy lên Genshin Impact Interactive Map để xem
      hướng dẫn bằng video nhé. Phần lớn độ khó của giải đố vùng này đến
      từ việc phải sử dụng quá thường xuyên Saurian.
    • File này (và hầu như các file của tôi) không thiết kế để hướng dẫn
      người mới chơi lần đầu Núi Thánh Viễn Cổ nên tôi thường viết khá ngắn gọn các
      bước giải đố, mục đích chỉ giúp các bạn không cần nhớ nhiều mà có
      thể đọc ngay trên tên waypoint để dễ dàng giải đố hơn thôi.
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

========================================================================
