========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Snezhnaya map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests.
    • Should complete all World Quests included in the file; don't skip
      because some quests contain chests, and even map-unlocking quests
      contain some chests that count toward achievements.

  ► Usage Notes:
    • When using the Quest file, please stay very calm and read the
      previous notes carefully if you run into any problems. If you've
      tried many ways and it still doesn't work, go to the Error channel
      or the Chat channel and ask me.
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

========================================================================
