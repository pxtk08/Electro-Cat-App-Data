========================================================================
               CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  GUIA E OBSERVAÇÕES ANTES DO USO
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se quiser
  desbloquear todos os Pontos de Teleporte.

  ► Teclas Recomendadas:
    • Você pode usar as mesmas teclas que eu:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve atribuir teclas para Invincible e Visual.

  ► Observações de Uso:
    • Os Pontos de Teleporte deste arquivo ajudam principalmente a
      desbloquear pontos que podem ser abertos imediatamente, antes de
      concluir qualquer missão, portanto, a lista pode não estar completa.
    • Os Pontos de Teleporte ausentes serão orientados no arquivo de Baús.

========================================================================
