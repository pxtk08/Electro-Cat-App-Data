========================================================================
               CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                           [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIA E OBSERVAÇÕES ANTES DO USO
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se quiser
  alcançar 100% de exploração do mapa do Mar Antigo.

  ► Teclas Recomendadas:
    • Você pode usar as mesmas teclas que eu:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, também atribua teclas para Invincible e Visual.

  ► Pré-requisitos:
    • Você deve concluir todas as Missões do Arconte.
    • Se quiser executar o arquivo de Baús da forma mais tranquila possível,
      execute primeiro o arquivo de Missões.

  ► Observações de Uso:
    • Ao usar meu arquivo de Missões para concluir missões, mantenha a calma
      e vá com calma. Verifique o que a missão pede em seguida antes de
      pressionar Teleport para evitar ter que voltar ou refazer a missão.
    • A maioria dos quebra-cabeças já possui orientações. Alguns não podem
      ser orientados, mas são bem simples. Alguns quebra-cabeças podem ser
      difíceis de imaginar usando apenas o arquivo (por exemplo,
      quebra-cabeças debaixo d'água); você pode combinar vídeos do YouTube
      ou guias do Mapa Interativo. Se já está acostumado com quebra-cabeças,
      usar o arquivo é bem prático, pois basta lembrar algumas etapas
      principais e teleportar conforme o arquivo para resolvê-los.
    • Se você só pretende executar este arquivo uma vez para procurar baús,
      leia com atenção estas observações e também as notas que digitei
      cuidadosamente, uma por uma, dentro do arquivo.
    • Não recomendo usar este arquivo para serviços de boosting de contas,
      pois ele exige bastante tempo. Mas, se ainda quiser usar dessa forma,
      execute o arquivo inteiro uma vez em uma conta para entender como
      ele funciona.

========================================================================
