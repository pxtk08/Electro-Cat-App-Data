Custom TP File By pxtk.08 - Vietnamese & English - Free



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Long Tích Tuyết Sơn.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Thế Giới Có Trong File, Đừng Skip Vì Có Một Số Quest Chứa Rương, Kể Cả Quest Mở Map Cũng Có Chứa 1 Số Rương Và Nó Có Tính Trong Thành Tựu.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Dragonspine Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All World Quests Included In The File, Don't Skip Because Some Quests Contain Chests, Even Map Unlocking Quests Contain Some Chests And They Count In Achievements.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.


