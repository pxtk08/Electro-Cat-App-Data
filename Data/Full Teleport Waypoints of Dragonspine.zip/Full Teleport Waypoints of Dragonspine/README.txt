========================================================================
               CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                          [ FREE VERSION ]
========================================================================

  ► Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)

------------------------------------------------------------------------
  GUIDE & NOTES BEFORE USE
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to unlock all Teleport Waypoints.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Usage Notes:
    • The Teleport Waypoints in this file mainly help you unlock waypoints
      that can be opened immediately before completing any quests, so the
      list may not be complete.
    • Missing Teleport Waypoints will be guided in the Chest File.

========================================================================
