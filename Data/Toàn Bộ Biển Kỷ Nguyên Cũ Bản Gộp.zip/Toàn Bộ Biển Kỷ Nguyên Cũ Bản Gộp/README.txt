========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Biển Kỷ Nguyên Cũ.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần.
    • Hãy chạy file Quest trước nếu muốn chạy file Rương một cách mượt
      mà nhất nhé.

  ► Lưu ý sử dụng:
    • Khi dùng file Quest của tôi để chạy quest, các bạn cần hết sức
      bình tĩnh và chậm rãi; các bạn cần xem quest yêu cầu gì tiếp theo
      rồi mới bấm tele tiếp để tránh việc phải tele lại hoặc làm lại
      quest mất thời gian.
    • Các giải đố hầu như đều đã được hướng dẫn, có một số không thể
      hướng dẫn thì cũng khá đơn giản. Vài giải đố sẽ hơi khó hình dung
      cách giải nếu chỉ dùng file (ví dụ như mấy giải đố dưới nước); gợi
      ý ae có thể kết hợp một số video YouTube hoặc hướng dẫn trên
      Interactive Map nhé. Nếu ae đã quen giải đố thì khi dùng file sẽ
      thấy khá tiện vì chỉ cần nhớ vài bước then chốt rồi tele theo file
      để giải.
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

========================================================================
