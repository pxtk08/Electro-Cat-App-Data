========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIA E OBSERVAÇÕES ANTES DE USAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia com atenção as informações abaixo se
  quiser concluir 100% do mapa de Snezhnaya.

  ► Recomendações de teclas:
    • Você pode usar minhas teclas como referência:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Também é recomendado atribuir teclas para Invincible e Visual.

  ► Requisitos antes de executar:
    • Conclua a Missão do Arcon.
    • Conclua todas as Missões do Mundo incluídas no arquivo. Não as pule,
      pois algumas missões contêm baús. Até missões que desbloqueiam o mapa
      contêm baús que contam para a conquista.

  ► Observações de uso:
    • Ao usar o arquivo de missões, mantenha a calma e leia a nota anterior
      com atenção sempre que encontrar um problema. Se tentar vários métodos
      e ainda não conseguir, pergunte no canal Error ou Chat.
    • Se quiser executar o arquivo apenas uma vez para procurar baús, leia
      estas observações e também as notas que digitei individualmente no
      arquivo.
    • Não recomendo muito usar este arquivo para boosting pago, pois exige
      tempo. Se ainda quiser usar, execute o arquivo inteiro uma vez em uma
      conta primeiro para entender como ele funciona.

========================================================================
