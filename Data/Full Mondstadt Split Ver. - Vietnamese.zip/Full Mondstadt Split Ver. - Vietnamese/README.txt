========================================================================
              CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Mondstadt.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần.
    • Nên làm hết Quest Thế Giới có trong file.

  ► Lưu ý sử dụng:
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn hãy
      chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về cách
      hoạt động của file này.

========================================================================
