========================================================================
              CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                          [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  GUIA & OBSERVAÇÕES ANTES DE USAR
------------------------------------------------------------------------
  Antes de usar este arquivo, todos precisam ler atentamente as partes
  abaixo que eu menciono se quiserem coletar 100% Gota de Asas Sombrias.

  ► Sugestão de teclas:
    • Você pode seguir como eu vinculo as teclas da seguinte forma:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, convém vincular teclas para Invincible, Visual.

  ► Requisitos antes de executar:
    • Você deve concluir o Arquivo de Quest e o Arquivo de Baús antes
      de executar este arquivo.
    • Como a Gota de Asas Sombrias é um item bastante especial, incluí
      também o guia neste arquivo.
========================================================================
