Custom TP File By pxtk.08 - Vietnamese & English - Free


- Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Mở Hết Các Điểm Tele.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Các Điểm Dịch Chuyển Còn Thiếu Sẽ Được Tôi Hướng Dẫn Trong File Rương Nhé.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Unlock All Teleport Waypoints.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Missing Teleport Waypoints Will Be Guided In The Chest File