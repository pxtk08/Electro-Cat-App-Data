========================================================================
                CUSTOM TP FILE BY pxtk.08  |  VIETNAMESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  HƯỚNG DẪN & LƯU Ý TRƯỚC KHI DÙNG
------------------------------------------------------------------------
  Trước khi dùng file này, mọi người cần đọc kĩ những phần sau đây tôi
  đề cập nếu muốn đạt 100% map Sumeru.

  ► Gợi ý gán phím:
    • Các bạn có thể tham khảo cách gán các nút của tôi như sau:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Ngoài ra nên gán các nút cho Invincible, Visual.

  ► Yêu cầu trước khi chạy:
    • Nên làm hết Quest Ma Thần.
    • Hãy chạy file Quest trước nếu muốn chạy file Rương một cách mượt
      mà nhất nhé.
    • Cần làm luôn nhiệm vụ mở Vực Đá Sâu để lấy bức tranh số 10 (đã bao
      gồm trong file Quest).
    • Cần chuẩn bị sẵn Mồi Câu Cam Lộ (mồi câu Sumeru).

  ► Lưu ý sử dụng:
    • Khi dùng file Quest của tôi để chạy quest, các bạn cần hết sức
      bình tĩnh và chậm rãi; các bạn cần xem quest yêu cầu gì tiếp theo
      rồi mới bấm tele tiếp để tránh việc phải tele lại hoặc làm lại
      quest mất thời gian.
    • Các hướng dẫn trong Bí Cảnh có trong quest ở trong file bắt buộc
      phải đi theo, không skip được (nếu muốn có thể thử).
    • Nếu bạn không nhận được quest "Phong Cảnh Tĩnh - Chương Sau" sau
      khi đã thử mọi cách theo hướng dẫn thì hãy tele tới vị trí tranh
      số 8 mình đã note, relog game ở đó và bạn sẽ nhận được quest (nhớ
      là phải nhặt rương trước khi relog rồi).
    • Hãy chú ý những con Kết Cấu Nguyên Thủy có thanh máu boss: sẽ có 5
      con như thế và bạn cần phải đánh hết chúng để nhận đủ 5 linh kiện,
      phục vụ cho việc mở khóa vị trí Obelisk về sau.
    • Ở Sumeru cũng có khá nhiều rương giết hết quái mới hiện nên mọi
      người chú ý để nhặt đủ rương nhé.
    • Có 1 rương cần hoàn thành Nhiệm vụ Ma Thần mới nhận được.
    • Nếu các bạn chỉ có nhu cầu chạy duy nhất 1 lần file để dò rương
      thì hãy đọc cẩn thận các lưu ý ở đây cũng như các note tôi đã cẩn
      thận gõ tay từng cái 1 trong file.
    • Còn đối với ai muốn dùng file này để cày thuê thì tôi không khuyên
      dùng lắm vì nó hơi mất thời gian. Nhưng nếu vẫn muốn thì các bạn
      hãy chạy qua một lượt cả file ở một acc nào đó để hình dung sơ về
      cách hoạt động của file này.

========================================================================
