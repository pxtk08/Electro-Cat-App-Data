Custom TP File By pxtk.08 - Vietnamese & English - Free



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Sumeru.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần.

- Khi Dùng File Quest Của Tôi Để Chạy Quest, Các Bạn Cần Hết Sức Bình Tĩnh Và Chậm Rãi, Các Bạn Cần Xem Quest Yêu Cầu Gì Tiếp Theo Rồi Mới Bấm Tele Tiếp Để Tránh Việc Phải Tele Lại Hoặc Làm Lại Quest Mất Thời Gian

- Hãy Chạy File Quest Trước Nếu Muốn Chạy File Rương Một Cách Mượt Mà Nhất Nhé.

- Có Một Số Chỗ Trong File Chest Yêu Cầu Tắt Kill Aura Vì Nếu Không Tắt Sẽ Vô Tình Đuổi Mất Mấy Con Hải Cẩu Nhỏ Đi, Lưu Ý Nhé.

- Các Giải Đố Bóng Nước Cần Chú Ý Đến Khoảng Thứ Tự Kích Hoạt Và Khoảng Thời Gian Giũa Các Lúc Phá Bóng Nước.

- Các Giải Đố Hầu Như Đều Đã Được Hướng Dẫn, Có Một Số Không Thể Hướng Dẫn Thì Cũng Khá Đơn Giản. Vài Giải Đố Sẽ Hơi Khó Hình Dung Cách Giải Nếu Chỉ Dùng File (Ví Dụ Như Mấy Giải Đố Dưới Nước), Gợi Ý Ae Có Thể Kết Hợp Một Số Video Youtube Hoặc Một Số Hướng Dẫn Trong Interactive Map Nhé. Nếu Ae Đã Quen Giải Đố Thì Khi Dùng File Sẽ Thấy File Khá Tiện Vì Ae Không Cần Nhớ Hết Mà Chỉ Cần Một Vài Bước Then Chốt, Sau Đó Tele Theo File Để Giải; Hơi Khó Nói Một Cách Rõ Ràng...

- Hãy Chú Ý Những Con Robot Có Thanh Máu Boss, Bạn Cần Thu Thập Đủ 7 Linh Kiện Để Mở Rương Sau Đó

- Ở Fontaine Có Một Số Rương Giết Quái Mới Hiện Nên Mọi Người Chú Ý Để Nhặt Đủ Rương Nhé.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Sumeru Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All Archon Quests.

- When Using My Quest File To Run Quests, Please Take It Slow And Stay Patient. You Need To Check What The Quest Requires Next Before Teleporting To The Next Spot To Avoid Having To Re-teleport Or Redo The Quest, Which Wastes Time.

- Please Run The Quest File First If You Want To Run The Chest File As Smoothly As Possible

- Some Spots In The Chest File Require Turning Off Kill Aura, Because Failing To Do So Might Accidentally Scare Away Small Seals. Please Keep This In Mind.

- Water Balloon Puzzles Require Attention To The Activation Order And The Time Intervals Between Popping Each Balloon.

- Most Puzzles Already Have Instructions; A Few That Cannot Be Guided Are Quite Simple. Some Puzzles Might Be Hard To Visualize Using Just The File (For Example, Underwater Puzzles). I Suggest Combining The File With Youtube Videos Or Interactive Map Guides. If You Are Experienced With Puzzles, The File Will Be Very Convenient Because You Don't Need To Memorize Everything, Only A Few Key Steps, And Then Teleport Following The File To Solve Them. It's A Bit Difficult To Explain Clearly...

- Pay Attention To Robots With Boss Health Bars; You Need To Collect All 7 Components To Open The Chest Afterward.

- In Fontaine, Some Chests Only Appear After Defeating Monsters, So Please Pay Attention To Collect All Chests.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.
