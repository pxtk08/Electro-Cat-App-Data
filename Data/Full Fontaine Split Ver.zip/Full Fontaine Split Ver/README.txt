========================================================================
                 CUSTOM TP FILE BY pxtk.08  |  ENGLISH
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  BEFORE YOU START
------------------------------------------------------------------------
  Before using this file, please read the following sections carefully
  if you want to achieve 100% Fontaine map exploration.

  ► Recommended Keybinds:
    • You can refer to how I bind keybinds as follows:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      In addition, you should bind keybinds for Invincible and Visual.

  ► Prerequisites:
    • Should complete all Archon Quests.
    • Please run the Quest file first if you want to run the Chest file
      as smoothly as possible.

  ► Usage Notes:
    • When using my Quest file to run quests, please take it slow and
      stay patient. Check what the quest requires next before
      teleporting to the next spot to avoid having to re-teleport or
      redo the quest, which wastes time.
    • Some spots in the Chest file require turning off Kill Aura,
      because failing to do so might accidentally scare away small
      seals. Please keep this in mind.
    • Water balloon puzzles require attention to the activation order
      and the time intervals between popping each balloon.
    • Most puzzles already have instructions; a few that cannot be
      guided are quite simple. Some puzzles might be hard to visualize
      using just the file (for example, underwater puzzles). I suggest
      combining the file with YouTube videos or Interactive Map guides.
      If you are experienced with puzzles, the file will be very
      convenient because you only need a few key steps and can teleport
      along the file to solve them.
    • Pay attention to robots with boss health bars; you need to collect
      all 7 components to open the chest afterward.
    • In Fontaine, some chests only appear after defeating enemies, so
      please pay attention to collect all chests.
    • If you only need to run the file once to scan for chests, then
      read carefully the notes here as well as the notes I have
      carefully hand-typed one by one in the file.
    • As for anyone who wants to use this file for account boosting /
      pilot services, I don't highly recommend it because it is a bit
      time-consuming. But if you still want to, you guys should run
      through the whole file once on some account to get a rough idea of
      how this file operates.

========================================================================
