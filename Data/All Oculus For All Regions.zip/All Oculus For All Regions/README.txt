Custom TP File By pxtk.08 - Vietnamese & English - Free


- Special Thanks To Khang (Gachatool.com - Vietnam Reseller Admin)



Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Nhặt 100% Thần Đồng.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Các Bạn Nên Chạy Xong File Rương Rồi Mới Chạy Đến File Này. Và File Này Sẽ Lược Bỏ Tất Cả Các Thần Đồng Đã Nhặt Ở Trong File Rương, Nên Bắt Buộc Phải Chạy File Rương Xong Mới Qua File Này Nếu Muốn Full Thần Đồng.

- File Này Sẽ Được Cập Nhật Cùng Với File Rương Nhé, File Rương Làm Đến Đâu Thì Tôi Sẽ Thêm Thần Đồng Của Khu Vực Đó Vào



Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Pick Up 100% Of The Oculus.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- You Should Finish The Chest File First Before Running This One. This File Omits All Oculi Already Collected In The Chest File, So Completing The Chest File First Is Required To Get All Oculi.

- This Files Will Be Upadated Alongside The Chest File; As I Add Progress To The Chest File, I Will Add The Oculus For That Area Accordingly.

