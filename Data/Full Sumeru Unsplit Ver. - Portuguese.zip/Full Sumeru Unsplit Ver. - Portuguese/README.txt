Custom TP File By pxtk.08 - Vietnamese & English & Portuguese - Free

- Special Thanks To @sukii0oo For Translating This File To Portuguese


Vie:
Trước Khi Dùng File Này, Mọi Người Cần Đọc Kĩ Những Phần Sau Đây Tôi Đề Cập Nếu Muốn Đạt 100% Map Sumeru.

Nhắc Nhở Chung:

- Các Bạn Có Thể Tham Khảo Cách Gán Các Nút Của Tôi Như Sau: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Telport. Ngoài Ra Nên Gán Các Nút Cho Invincible, Visual.

- Nên Làm Hết Quest Ma Thần.

- Khi Dùng File Quest Của Tôi Để Chạy Quest, Các Bạn Cần Hết Sức Bình Tĩnh Và Chậm Rãi, Các Bạn Cần Xem Quest Yêu Cầu Gì Tiếp Theo Rồi Mới Bấm Tele Tiếp Để Tránh Việc Phải Tele Lại Hoặc Làm Lại Quest Mất Thời Gian.

- Hãy Chạy File Quest Trước Nếu Muốn Chạy File Rương Một Cách Mượt Mà Nhất Nhé.

- Các Hướng Dẫn Trong Bí Cảnh Có Trong Quest Ở Trong File Bắt Buộc Phải Đi Theo, Không Skip Được, Nếu Muốn Có Thể Thử.

- Nếu Bạn Không Nhận Được Quest "Phong Cảnh Tĩnh - Chương Sau" Sau Khi Đã Thử Mọi Cách Theo Hướng Dẫn Thì Hãy Tele Tới Vị Trí Tranh Số 8 Mình Đã Note, Relog Game Ở Đó Và Bạn Sẽ Nhận Được Quest (Nhớ Là Phải Nhặt Rương Trước Khi Relog Rồi).

- Cần Làm Luôn Nhiệm Vụ Mở Vực Đá Sâu Để Lấy Bức Tranh Số 10 (Đã Bao Gồm Trong File Quest).

- Cần Chuẩn Bị Sẵn Mồi Câu Cam Lộ (Mồi Câu Sumeru).

- Hãy Chú Ý Những Con Kết Cấu Nguyên Thủy Có Thanh Máu Boss, Sẽ Có 5 Con Như Thế Và Bạn Cần Phải Đánh Hết Chúng Để Nhận Đủ 5 Linh Kiện, Phục Vụ Cho Việc Mở Khóa Vị Tri Obelisk Về Sau.

- Ở Sumeru Cũng Có khá Nhiều Rương Giết Hết Quái Mới Hiện Nên Mọi Người Chú Ý Để Nhặt Đủ Rương Nhé.

- Có 1 Rương Cần Hoàn Thành Nhiệm Vụ Ma Thần Mới Nhận Được.

- Nếu Các Bạn Chỉ Có Nhu Cầu Chạy Duy Nhất 1 Lần File Để Dò Rương Thì Hãy Đọc Cẩn Thận Các Lưu Ý Ở Đây Cũng Như Các Note Tôi Đã Cẩn Thận Gõ Tay Từng Cái 1 Trong File. Còn Đối Với Ai Muốn Dùng File Này Để Cày Thuê Thì Tôi Không Khuyên Dùng Lắm Vì Nó Hơi Mất Thời Gian. Nhưng Nếu Vẫn Muốn Thì Các Bạn Hãy Chạy Qua Một Lượt Cả File Ở Một Acc Nào Đó Để Hình Dung Sơ Về Cách Hoạt Động Của File Này.


Eng:
Before Using This File, Please Read The Following Sections Carefully If You Want To Achieve 100% Sumeru Map Exploration.

General Reminders:

- You Can Refer To How I Bind Keybinds As Follows: = - Kill Aura / U - Previous Point / I - Next Point / R - Teleport / F12 - Drawpoint / Delete - Entities Teleport. In Addition, You Should Bind Keybinds For Invincible, Visual.

- Should Complete All Archon Quests.

- When Using My Quest File To Run Quests, Please Take It Slow And Stay Patient. You Need To Check What The Quest Requires Next Before Teleporting To The Next Spot To Avoid Having To Re-teleport Or Redo The Quest, Which Wastes Time.

- Please Run The Quest File First If You Want To Run The Chest File As Smoothly As Possible.

- Instructions Inside Domain Quests Included In The File Are Mandatory And Cannot Be Skipped, Feel Free To Test If You Want.

- If You Don't Get The "Static Views: Part 2" Quest After Trying Everything In The Guide, Teleport To Painting Location No. 8 That I Noted, Relog The Game There, And You Will Get The Quest (Remember To Collect The Chest Before Relogging).

- Need To Complete The Chasm Unlock Quest To Get Painting #10 (Already Included In Quest File).

- Please Prepare Sugardew Bait (Sumeru Fishing Bait) In Advance.

- Pay Attention To Primal Constructs With Boss Health Bars, Defeat All 5 To Get Components Needed For Unlocking Primal Obelisks Later.

- Many Sumeru Chests Only Spawn After Defeating All Surrounding Enemies, Pay Attention To Collect Them All.

- There Is 1 Chest That Requires Completing The Archon Quest To Obtain.

- If You Only Need To Run The File Once To Scan For Chests Then Read Carefully The Notes Here As Well As The Notes I Have Carefully Hand-Typed One By One In The File. As For Anyone Who Wants To Use This File For Account Boosting / Pilot Services, I Don't Highly Recommend It Because It Is A Bit Time-Consuming. But If You Still Want To, You Guys Run Through The Whole File Once On Some Account To Get A Rough Idea Of How This File Operates.


