========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser alcançar 100% de exploração no mapa de Liyue.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte (na verdade,
      até o momento em que terminei este arquivo, nem eu mesmo tinha
      concluído todas).
    • É recomendável concluir todas as Missões do Mundo incluídas no
      arquivo; não pule nenhuma, pois algumas contêm baús - até mesmo
      missões de desbloqueio de mapa contêm baús que contam para
      conquistas.

  ► Notas de Uso:
    • Na prática, Liyue tem 1.135 baús no total, mas o arquivo contém
      apenas 1.129 baús porque: 1 baú coletado no arquivo de Mondstadt
      conta tanto para Mondstadt quanto para Liyue, 2 baús coletados na
      Espinha do Dragão também contam para ambas as regiões, e 3 baús de
      Natlan, por algum motivo, também contam para Liyue (caso tenha
      dúvida).
    • Se você só precisa rodar o arquivo uma única vez para procurar
      baús, leia com atenção os avisos aqui, bem como as notas que eu
      digitei cuidadosamente uma por uma dentro do arquivo.
    • Quanto a quem pretende usar este arquivo para serviços de boost /
      pilot de contas, eu não recomendo muito porque leva um pouco de
      tempo. Mas, se mesmo assim quiser usar, faça uma passagem completa
      pelo arquivo em alguma conta primeiro para ter uma noção geral de
      como ele funciona.

========================================================================
