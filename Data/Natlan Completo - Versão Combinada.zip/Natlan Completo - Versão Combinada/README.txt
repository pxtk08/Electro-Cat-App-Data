========================================================================
                CUSTOM TP FILE BY pxtk.08  |  PORTUGUESE
                            [ FREE VERSION ]
========================================================================

------------------------------------------------------------------------
  ANTES DE COMEÇAR
------------------------------------------------------------------------
  Antes de usar este arquivo, leia atentamente as seções a seguir se
  você quiser alcançar 100% de exploração no mapa de Natlan.

  ► Atalhos de Teclado Recomendados:
    • Você pode usar como referência a forma como eu configuro meus atalhos:
        [ = ]       Kill Aura
        [ U ]       Previous Point
        [ I ]       Next Point
        [ R ]       Teleport
        [ F12 ]     Drawpoint
        [ Delete ]  Entities Teleport
      Além disso, você também deve configurar teclas para Invincible e Visual.

  ► Pré-requisitos:
    • É recomendável concluir todas as Missões do Arconte.
    • Execute o arquivo de Missões primeiro se quiser rodar o arquivo de
      Baús da forma mais tranquila possível.

  ► Notas de Uso:
    • Ao usar meu arquivo de Missões, vá com calma e paciência: confira
      o que a missão pede em seguida antes de se teleportar para o
      próximo ponto, evitando ter que refazer o teleporte ou a missão.
    • O total de baús de Natlan 1 nas conquistas é 411, mas meu arquivo
      tem 408 porque os 3 restantes são bem difíceis de pegar: cada
      tribo de Natlan tem 2 Pilares de Desafio Totem (12 no total), cada
      um com 1 chefe de mecânica especial. Cada chefe possui 3
      conquistas; ao completar todas as 36 conquistas, você recebe os 3
      baús finais, totalizando 411.
    • Há vários quebra-cabeças em Natlan difíceis de explicar apenas por
      texto porque encadeiam muitas ações. Se tiver dúvida em algum
      passo, consulte o Genshin Impact Interactive Map para ver um guia
      em vídeo. A maior dificuldade dessa região vem do uso constante de
      Saurianos.
    • Os Desafios de Sauriano nos NPCs normalmente dão 3 baús ao atingir
      o rank SS, então tente alcançar a pontuação logo na primeira
      tentativa para não perder tempo.
    • Este arquivo (assim como a maioria dos meus arquivos) não foi
      feito para ensinar Natlan a iniciantes, por isso escrevo os passos
      de forma bem resumida - apenas para você ler direto no nome do
      waypoint e resolver o enigma mais facilmente.
    • Se você só precisa rodar o arquivo uma única vez para procurar
      baús, leia com atenção os avisos aqui, bem como as notas que eu
      digitei cuidadosamente uma por uma dentro do arquivo.
    • Quanto a quem pretende usar este arquivo para serviços de boost /
      pilot de contas, eu não recomendo muito porque leva um pouco de
      tempo. Mas, se mesmo assim quiser usar, faça uma passagem completa
      pelo arquivo em alguma conta primeiro para ter uma noção geral de
      como ele funciona.

========================================================================
